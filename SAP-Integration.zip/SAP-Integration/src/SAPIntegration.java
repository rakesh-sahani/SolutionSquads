
/**
 * 
 */

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider; //Connection Settings or String

/**
 * @author sumit
 *
 */
public class SAPIntegration {

	static String DESTINATION_NAME1 = "ABAP_AS_WITHOUT_POOL"; // Destination File Name
	static String DESTINATION_NAME2 = "ABAP_AS_WITH_POOL"; // Destination File Name
	static {
		Properties connectProperties = new Properties();
		connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "172.18.16.185");
		connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, "/H/202.168.94.189");
		connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "00");
		connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "500");
		connectProperties.setProperty(DestinationDataProvider.JCO_USER, "IGT-RAJESH");
		connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, "Werks12#");
		connectProperties.setProperty(DestinationDataProvider.JCO_LANG, "en");
		createDestinationDataFile(DESTINATION_NAME1, connectProperties);
		connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
		connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
		createDestinationDataFile(DESTINATION_NAME2, connectProperties);

	}

	static void createDestinationDataFile(String destinationName, Properties connectProperties) {
		File destCfg = new File(destinationName + ".jcoDestination");
		try {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			connectProperties.store(fos, "for tests only !");
			fos.close();
		} catch (Exception e) {
			throw new RuntimeException("Unable to create the destination files", e);
		}
	}

	public static void step1Connect() throws JCoException {
		JCoDestination destination = JCoDestinationManager.getDestination(DESTINATION_NAME1);
		System.out.println("Attributes:");
		System.out.println(destination.getAttributes());
		System.out.println();
	}

	public static void sapConnection() throws JCoException {
		JCoDestination destination = JCoDestinationManager.getDestination(DESTINATION_NAME2);
		destination.ping();
		System.out.println("Attributes:");
		System.out.println(destination.getAttributes());
		System.out.println();
	}

	public static void simpleCall() throws JCoException {
		JCoDestination destination = JCoDestinationManager.getDestination(DESTINATION_NAME2);
		JCoFunction function = destination.getRepository().getFunction("STFC_CONNECTION");
		if (function == null)
			throw new RuntimeException("BAPI_COMPANYCODE_GETLIST not found in SAP.");
		function.getImportParameterList().setValue("REQUTEXT", "Hello SAP");
		try {
			function.execute(destination);
		} catch (AbapException e) {
			System.out.println(e.toString());
			return;
		}
		System.out.println("STFC_CONNECTION finished:");//ZHR_EMP_NO_CREATE
		System.out.println(" Echo: " + function.getExportParameterList().getString("ECHOTEXT"));
		System.out.println(" Response: " + function.getExportParameterList().getString("RESPTEXT"));
		System.out.println();
	}

	public static void workWithStructure() throws JCoException {
		JCoDestination destination = JCoDestinationManager.getDestination(DESTINATION_NAME2);
		JCoFunction function = destination.getRepository().getFunction("RFC_SYSTEM_INFO");
		if (function == null)
			throw new RuntimeException("BAPI_COMPANYCODE_GETLIST not found in SAP.");
		try {
			function.execute(destination);
		} catch (AbapException e) {
			System.out.println(e.toString());
			return;
		}
		JCoStructure exportStructure = function.getExportParameterList().getStructure("RFCSI_EXPORT");
		System.out.println("System info for " + destination.getAttributes().getSystemID() + ":\n");
		for (int i = 0; i < exportStructure.getMetaData().getFieldCount(); i++) {
			System.out.println(exportStructure.getMetaData().getName(i) + ":\t" + exportStructure.getString(i));
		}
		System.out.println();
		// JCo still supports the JCoFields, but direct access via getXX is more
		// efficient as field iterator
		System.out.println("The same using field iterator: \nSystem info for "
				+ destination.getAttributes().getSystemID() + ":\n");
		for (JCoField field : exportStructure) {
			System.out.println(field.getName() + ":\t" + field.getString());
		}
		System.out.println();
	}
	
	
	
	public static void callRfcBapi() throws JCoException {
		JCoDestination destination = JCoDestinationManager.getDestination(DESTINATION_NAME2);
		JCoFunction function = destination.getRepository().getFunction("BAPI_COMPANYCODE_GETLIST");
		if (function == null)
			throw new RuntimeException("BAPI_COMPANYCODE_GETLIST	not found in SAP.");
		try {

			function.execute(destination);
		} catch (AbapException e) {
			System.out.println(e.toString());
			return;
		}
		JCoStructure returnStructure = function.getExportParameterList().getStructure("RETURN");
		if (!(returnStructure.getString("TYPE").equals("") || returnStructure.getString("TYPE").equals("S"))) {
			throw new RuntimeException(returnStructure.getString("MESSAGE"));
		}
		JCoTable codes = function.getTableParameterList().getTable("COMPANYCODE_LIST");
		for (int i = 0; i < codes.getNumRows(); i++) {
			codes.setRow(i);
			System.out.println(codes.getString("COMP_CODE") + '\t' + codes.getString("COMP_NAME"));
		}
	}
	public static void main(String[] args) throws JCoException {

		sapConnection();
		simpleCall();
		workWithStructure();
		
		callRfcBapi();
	}

}
